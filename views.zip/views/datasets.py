#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 31 19:20:23 2024

@author: user
"""

import streamlit as st
import pandas as pd
from sklearn.datasets import load_breast_cancer


class Dataset:
    
    class variables:
        
        pageTitle = "Datasets"

    def __init__(self, enabled = None):
        
        self.enabled = enabled
        
    def view(self,model):
        
        upload_file = st.sidebar.file_uploader(label = "Please Upload a file :")

        if upload_file is not None and self.enabled == True:
            st.title(model.pageTitle)
            data = pd.read_table(upload_file)
            
            
            #cancer = load_breast_cancer()
            #cancer_data = pd.read_csv(upload_file,
            #                          delimiter= ',',
            #                          names=cancer.feature_names)
            
            #cancer_data["target"] = pd.Series(cancer.target)

            if st.checkbox('Show dataframe'):#show/hide data
                
                #st.write(cancer_data)
                st.write(data)
                
        if upload_file is not None and self.enabled == False:
            data = pd.read_table(upload_file)

            #cancer = load_breast_cancer()
            #cancer_data = pd.read_csv(upload_file,
            #                              delimiter= ',',
            #                              names=cancer.feature_names)
            #    
            #cancer_data["target"] = pd.Series(cancer.target)

            return data        
            #return cancer_data












