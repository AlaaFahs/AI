#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 31 19:50:24 2024

@author: user
"""

import numpy
import pandas as pd
import seaborn as sn
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import ListedColormap, BoundaryNorm
from sklearn import neighbors
import matplotlib.patches as mpatches
import streamlit as st
import matplotlib.patches as mpatches
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay


class plots:
    def confusion_matrix(self, model, X_test, y_test):
        
        st.subheader("Confusion Matrix")
        ConfusionMatrixDisplay.from_estimator(model,X_test,y_test)   
        st.set_option('deprecation.showPyplotGlobalUse', False)
        st.pyplot()
 

    def fruitsplot(self, X1 , X2 , X3, y):
        
        fig = plt.figure()
        ax = fig.add_subplot(111, projection = '3d')
        ax.scatter(X1 , X2 , X3, c = y, marker = 'o', s=100)
        ax.set_xlabel("mass")
        ax.set_ylabel("width")
        ax.set_zlabel("height")
        st.pyplot(fig)
